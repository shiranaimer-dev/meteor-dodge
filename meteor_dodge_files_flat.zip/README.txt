# Meteor Dodge (גרסת PWA ל-GitHub Pages)

### מה זה?
משחק חלל קטן — עובד גם בטלפון, ניתן להוסיף למסך הבית, וממשיך לעבוד בלי אינטרנט אחרי טעינה ראשונה.

### איך לפרסם ב-GitHub Pages
1. התחברי ל-GitHub ולחצי "+" → **New repository**.
2. תני שם, למשל `meteor-dodge`, והשאירי Public.
3. גררי לתוך המאגר את הקבצים האלו (או את ה-ZIP כשהוא *נפתח*): `index.html`, `manifest.webmanifest`, `sw.js`, `icon-192.png`, `icon-512.png`.
4. לכי ל-**Settings → Pages**.
5. Source: בחרי **Deploy from a branch**; Branch: **main**; Folder: **/** (root); שמרי.
6. חכי כדקה—למעלה יופיע קישור לאתר (`https://USER.github.io/meteor-dodge`).

### טיפים
- כדי להתקין לנייד: פתחי את הקישור → תפריט הדפדפן → Add to Home Screen.
- אם עדכנת קבצים והאתר לא מתעדכן: מחקי נתוני אתר (Site data) בדפדפן כדי לרענן Service Worker.
